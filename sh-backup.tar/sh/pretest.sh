#!/bin/bash -eux

testfile="$HOME/test/*.c"

#php -r "echo(rawurlencode(\"aaa\"));"
#php -r "echo(rawurldecode(\"aaa\"));"

check_str () {
	if [ $4 != $5 ] ; then
		echo "Failed $2"
		echo "INPUT : $3"
		echo "Your $1 : $4"
		echo "Correct $1 : $5"
		return 0
	fi
}

check_result () {
	for line in `cat teststr.txt`
	do
		encode_teststr=$line
		c_encode_output=`echo -n $encode_teststr | ./a.out -e`
		php_encode_output=`php -r "echo(rawurlencode(\"$encode_teststr\"));"`
		check_str "ENCODE" $1 $line $c_encode_output $php_encode_output
		decode_teststr=$php_encode_output
		c_decode_output=`echo -d $decode_teststr | ./a.out -e`
		php_decode_output=`php -r "echo(rawurldecode(\"$decode_teststr\"));"`
		check_str "DECODE" $1 $line $c_decode_output $php_decode_output		
		###########################################
		#if [ $c_output != $php_output ] ; then
                #	echo "Failed $1"
		#	echo "INPUT : $line"
		#	echo "Your ENCODE : $c_output"
		#	echo "Correct ENCODE : $php_output"
		#	return 0
        	#fi
		###########################################
	done
	echo "Congratulations!"
}

for filename in $testfile
do
	if gcc $filename ; then
		check_result $filename
	else
		echo "$filename is compile error"
	fi
done

echo 'TEST FINISH'
exit 0
