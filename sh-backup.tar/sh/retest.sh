#!/bin/bash -eux

testfile="$HOME/test/*"

#php -r "echo(rawurlencode(\"aaa\"));"
#php -r "echo(rawurldecode(\"aaa\"));"

check_result () {
	teststr=""
	for line in `cat teststr.txt`
	do
		teststr=$teststr$line
	done
	c_output=`echo -n $teststr | ./a.out -e`
	php_output=`php -r "echo(rawurlencode(\"$teststr\"));"`
	if [ $c_output = $php_output ] ; then
		echo "OK"
	else
		echo "Failed"
	fi	
}

gcc 01.c
check_result

#for filename in $testfile
#do
#	if [ -f "a.out" ] ; then
#		rm a.out
#	fi
#	gcc $filename
#	if [ -f "a.out" ] ; then	
#		check_result $filename
#	else
#		echo "$filename is compile error"
#	fi
#done

echo 'TEST FINISH'
exit 0
